//
//  restauraunTableViewCell.swift
//  U10716012FoodPin
//
//  Created by G509User on 2019/12/4.
//  Copyright © 2019 blyat. All rights reserved.
//

import UIKit

class restauraunTableViewCell: UITableViewCell {

    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var locationLabel: UILabel!
    @IBOutlet var typeLabelL: UILabel!
    @IBOutlet var thumbnailImageView: UIImageView!
//        {
//        didSet{thumbnailImageView.layer.cornerRadius = thumbnailImageView.bounds.width / 2
//        thumbnailImageView.clipsToBounds = true
//            }
//    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
